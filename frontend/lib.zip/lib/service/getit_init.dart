import 'package:mudabbir/data/local/database_helper.dart';
import 'package:mudabbir/data/local/local_database.dart';
import 'package:mudabbir/domain/repository/budget_repository/budget_repository.dart';
import 'package:mudabbir/domain/repository/budget_repository/budget_repository.dart';
import 'package:mudabbir/domain/repository/home_repository/home_repository.dart';
import 'package:mudabbir/domain/repository/home_repository/home_repository.dart';
import 'package:mudabbir/domain/repository/post_repository/posts_repository.dart';
import 'package:mudabbir/service/popup_service/popup_service.dart';
import 'package:mudabbir/service/posts_service/posts_service.dart';
import 'package:get_it/get_it.dart';
import 'package:mudabbir/service/navigation_service.dart';
import 'package:mudabbir/service/api_service.dart';
import 'package:mudabbir/service/hive_service.dart';
import 'package:mudabbir/service/routing_service/auth_notifier.dart';
import 'package:mudabbir/domain/repository/user_repository/user_repository.dart';

GetIt getIt = GetIt.instance;

void setupLocator() {
  getIt.registerLazySingleton<NavigationService>(() => NavigationService());
  getIt.registerLazySingleton<ApiService>(() => ApiService());
  getIt.registerLazySingleton<AuthNotifier>(() => AuthNotifier());
  getIt.registerLazySingleton<HiveService>(() => HiveService());
  getIt.registerLazySingleton<UserRepository>(
    () => UserRepository(getIt<ApiService>()),
  );
  // Our new database singletons
  getIt.registerLazySingleton<LocalDatabase>(() => LocalDatabase.instance);
  getIt.registerLazySingleton<DbHelper>(() => DbHelper(getIt<LocalDatabase>()));
  getIt.registerLazySingleton<PostRepository>(() => PostRepository());
  getIt.registerLazySingleton<PostService>(() => PostService());
  getIt.registerLazySingleton<HomeRepository>(() => HomeRepository());

  getIt.registerLazySingleton<PopupService>(() => PopupService());
  getIt.registerLazySingleton<BudgetRepository>(() => BudgetRepository());
}
