import 'package:dartz/dartz.dart';
import 'package:mudabbir/constants/api_constants.dart';
import 'package:mudabbir/constants/hive_constants.dart';
import 'package:mudabbir/data/network/failure.dart';
import 'package:mudabbir/data/network/request_helper.dart';
import 'package:mudabbir/domain/models/user/user_model.dart';
import 'package:mudabbir/service/getit_init.dart';
import 'package:mudabbir/service/hive_service.dart';

class ApiService {
  Future<Either<Failure, UserModel>> login(
    String email,
    String password,
  ) async {
    return await requestData(
      method: HttpMethod.POST,
      body: {'email': email, 'password': password},
      url: '${ApiConstants.baseUrl}/api/login',
      parser: (json) {
        final userJson = json['user'];
        final user = UserModel.fromJson(userJson);

        storeTokenAndUser(user, json['token']); // save token + user info
        return user;
      },
    );
  }

  Future<Either<Failure, UserModel>> register(
    String name,
    String email,
    String password,
    String passwordConfirmation,
  ) async {
    return await requestData(
      method: HttpMethod.POST,
      body: {
        'email': email,
        'name': name,
        'password': password,
        'password_confirmation': passwordConfirmation,
      },
      url: '${ApiConstants.baseUrl}/api/register',
      parser: (json) {
        final userJson = json['user'];
        final user = UserModel.fromJson(userJson);

        storeTokenAndUser(user, json['token']); // save token + user info
        return user;
      },
    );
  }

  Future<void> storeTokenAndUser(UserModel user, String token) async {
    final hive = getIt<HiveService>();
    await hive.setValue(HiveConstants.savedToken, token);

    // Save user info for HomePage green-dot
    await hive.setValue(HiveConstants.savedUserInfo, {
      'email': user.email,
      'name': user.name,
    });
  }
}
