import 'package:flutter/material.dart';
import 'package:mudabbir/constants/hive_constants.dart';
import 'package:mudabbir/data/local/local_database.dart';
import 'package:mudabbir/service/getit_init.dart';
import 'package:mudabbir/service/hive_service.dart';

class AuthNotifier extends ChangeNotifier {
  final HiveService _hiveService = getIt<HiveService>();
  bool _isLoggedIn = false;
  bool _isInitialized = false;

  bool get isLoggedIn => _isLoggedIn;
  bool get isInitialized => _isInitialized;

  /// The constructor is the entry point for this class.
  AuthNotifier() {
    _checkLoginStatusAtStartup();
  }

  /// This private method runs only once when the app starts.
  Future<void> _checkLoginStatusAtStartup() async {
    final token = _hiveService.getValue(HiveConstants.savedToken);

    if (token != null) {
      _isLoggedIn = true;

      // Initialize the database for the existing user session.
      final user = _hiveService.getValue(HiveConstants.savedUserInfo);
      if (user != null && user is Map) {
        await LocalDatabase.instance.initForUser(user['name']);
        print('Database initialized for existing user: ${user['name']}');
      }
    } else {
      _isLoggedIn = false;
    }

    _isInitialized = true;
    notifyListeners();
  }

  /// Call this from your LoginView AFTER a successful API login.
  Future<void> didLogin(Map<String, dynamic> user, String token) async {
    try {
      // 1. Save session data to Hive.
      _hiveService.setValue(HiveConstants.savedToken, token);
      _hiveService.setValue(HiveConstants.savedUserInfo, user);

      // 2. Initialize the database for the new user session.
      await LocalDatabase.instance.initForUser(user['name']);
      print('Database initialized for new user: ${user['name']}');

      // 3. Update the state.
      _isLoggedIn = true;

      // 4. Notify listeners immediately
      notifyListeners();

      print('Auth state updated: isLoggedIn = $_isLoggedIn');
    } catch (e) {
      print('Error during login: $e');
      // Rollback on error
      _hiveService.deleteValue(HiveConstants.savedToken);
      _hiveService.deleteValue(HiveConstants.savedUserInfo);
      _isLoggedIn = false;
      notifyListeners();
      rethrow;
    }
  }

  /// Call this from your UI when the user logs out.
  Future<void> didLogout() async {
    // 1. Clear session data from Hive.
    _hiveService.deleteValue(HiveConstants.savedToken);
    _hiveService.deleteValue(HiveConstants.savedUserInfo);

    // TODO: You might want to close the database here if necessary.

    // 2. Update state and notify the router.
    _isLoggedIn = false;
    notifyListeners();
  }

  // Remove the refresh method as it's not needed
}
