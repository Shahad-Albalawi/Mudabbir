import 'package:mudabbir/constants/hive_constants.dart';
import 'package:mudabbir/data/local/local_database.dart';
import 'package:mudabbir/persentation/home/home_page.dart';
import 'package:mudabbir/persentation/login/login_view.dart';
import 'package:mudabbir/persentation/onboarding/onboarding_view.dart';
import 'package:mudabbir/persentation/register/register_view.dart';
import 'package:mudabbir/service/getit_init.dart';
import 'package:mudabbir/service/hive_service.dart';
import 'package:mudabbir/service/navigation_service.dart';
import 'package:mudabbir/service/routing_service/auth_notifier.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

class AppRouter {
  static GoRouter get router {
    return GoRouter(
      navigatorKey: getIt<NavigationService>().navigatorKey,
      refreshListenable: getIt<AuthNotifier>(),
      initialLocation: '/',
      redirect: (context, state) {
        // Get instances of your services.
        final hive = getIt<HiveService>();
        final authNotifier = getIt<AuthNotifier>();

        // Wait for auth initialization to complete
        if (!authNotifier.isInitialized) {
          return null; // Let the app continue loading
        }

        // Check conditions.
        final hasSeenOnboarding =
            hive.getValue(HiveConstants.savedFirstTime) == true;
        final isLoggedIn = authNotifier.isLoggedIn;
        final current = state.matchedLocation;

        print(
          'Router redirect: hasSeenOnboarding=$hasSeenOnboarding, isLoggedIn=$isLoggedIn, current=$current',
        );

        // Handle onboarding first
        if (!hasSeenOnboarding && current != '/onboarding') {
          print('Redirecting to onboarding');
          return '/onboarding';
        }

        // Handle authentication
        if (hasSeenOnboarding &&
            !isLoggedIn &&
            current != '/login' &&
            current != '/register') {
          print('Redirecting to login');
          return '/login';
        }

        // If logged in and trying to access login/register, redirect to home
        if (isLoggedIn && (current == '/login' || current == '/register')) {
          print('Redirecting to home (already logged in)');
          return '/';
        }

        print('No redirect needed');
        return null; // No redirect needed.
      },
      routes: [
        GoRoute(
          path: '/',
          name: 'home',
          pageBuilder: (context, state) => _buildPage(const HomePage()),
        ),
        GoRoute(
          path: '/login',
          name: 'login',
          pageBuilder: (context, state) => _buildPage(LoginView()),
        ),
        GoRoute(
          path: '/register',
          name: 'register',
          pageBuilder: (context, state) => _buildPage(RegisterView()),
        ),
        GoRoute(
          path: '/onboarding',
          name: 'onboarding',
          pageBuilder: (context, state) => _buildPage(const OnboardingView()),
        ),
      ],
    );
  }

  static Page _buildPage(Widget child) {
    return CustomTransitionPage(
      child: child,
      transitionDuration: const Duration(milliseconds: 400),
      transitionsBuilder: (context, animation, secondaryAnimation, child) {
        const begin = Offset(1.0, 0.0);
        const end = Offset.zero;
        const curve = Curves.easeInOut;

        final tween = Tween(
          begin: begin,
          end: end,
        ).chain(CurveTween(curve: curve));
        final fadeTween = Tween<double>(begin: 0, end: 1);

        return SlideTransition(
          position: animation.drive(tween),
          child: FadeTransition(
            opacity: animation.drive(fadeTween),
            child: child,
          ),
        );
      },
    );
  }
}
