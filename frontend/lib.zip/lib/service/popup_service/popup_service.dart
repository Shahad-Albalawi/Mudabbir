import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get_it/get_it.dart';
import 'package:dartz/dartz.dart';
import 'package:mudabbir/data/local/database_helper.dart';
import 'package:mudabbir/domain/repository/home_repository/home_repository.dart';
import 'package:mudabbir/persentation/resources/color_manager.dart';
import 'package:mudabbir/service/navigation_service.dart';

const String TAG = 'MudabbirApp_DEBUG';

class PopupService {
  final _db = GetIt.I<DbHelper>();
  final _homeRepository = GetIt.I<HomeRepository>();

  Future<void> showAddIncomePopup(BuildContext context) async {
    print('$TAG: showAddIncomePopup called.');
    await _showTransactionPopup(context, 'income');
  }

  Future<void> showAddExpensePopup(BuildContext context) async {
    print('$TAG: showAddExpensePopup called.');
    await _showTransactionPopup(context, 'expense');
  }

  Future<void> showAddChallengePopup(BuildContext context) async {
    final formKey = GlobalKey<FormState>();
    final nameController = TextEditingController();
    final startController = TextEditingController();
    final endController = TextEditingController();
    final statusController = TextEditingController();

    await showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: Theme.of(context).primaryColor.withOpacity(0.1),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Icon(
                Icons.flag,
                color: Theme.of(context).primaryColor,
                size: 24,
              ),
            ),
            const SizedBox(width: 12),
            const Text('Add Challenge'),
          ],
        ),
        content: SizedBox(
          width: MediaQuery.of(context).size.width * 0.8,
          child: Form(
            key: formKey,
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  _buildTextFormField(
                    controller: nameController,
                    label: 'Challenge Name',
                    icon: Icons.title,
                    validator: (value) {
                      if (value?.isEmpty ?? true) {
                        return 'Challenge name is required';
                      }
                      if (value!.length < 3) {
                        return 'Name must be at least 3 characters';
                      }
                      return null;
                    },
                  ),
                  const SizedBox(height: 16),
                  _buildDateField(
                    controller: startController,
                    label: 'Start Date',
                    context: context,
                    validator: (value) {
                      if (value?.isEmpty ?? true) {
                        return 'Start date is required';
                      }
                      return null;
                    },
                  ),
                  const SizedBox(height: 16),
                  _buildDateField(
                    controller: endController,
                    label: 'End Date',
                    context: context,
                    validator: (value) {
                      if (value?.isEmpty ?? true) {
                        return 'End date is required';
                      }
                      // Validate end date is after start date
                      if (startController.text.isNotEmpty) {
                        final startDate = DateTime.tryParse(
                          startController.text,
                        );
                        final endDate = DateTime.tryParse(value!);
                        if (startDate != null &&
                            endDate != null &&
                            endDate.isBefore(startDate)) {
                          return 'End date must be after start date';
                        }
                      }
                      return null;
                    },
                  ),
                  const SizedBox(height: 16),
                  _buildDropdownField<String>(
                    value: statusController.text.isEmpty
                        ? null
                        : statusController.text,
                    label: 'Status',
                    icon: Icons.task_alt,
                    items: ['Active', 'Inactive', 'Completed', 'Paused']
                        .map(
                          (status) => DropdownMenuItem(
                            value: status,
                            child: Text(status),
                          ),
                        )
                        .toList(),
                    onChanged: (value) => statusController.text = value ?? '',
                    validator: (value) {
                      if (value?.isEmpty ?? true) {
                        return 'Status is required';
                      }
                      return null;
                    },
                  ),
                ],
              ),
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () async {
              if (formKey.currentState?.validate() ?? false) {
                try {
                  await _db.insert('challenges', {
                    'name': nameController.text.trim(),
                    'start_date': startController.text,
                    'end_date': endController.text,
                    'status': statusController.text,
                  });
                  Navigator.pop(context);
                  _showSuccessSnackBar(
                    context,
                    'Challenge added successfully!',
                  );
                } catch (error) {
                  _showErrorSnackBar(
                    context,
                    'Failed to add challenge: $error',
                  );
                }
              }
            },
            style: ElevatedButton.styleFrom(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(8),
              ),
            ),
            child: const Text('Save Challenge'),
          ),
        ],
      ),
    );
  }

  Future<void> _showTransactionPopup(BuildContext context, String type) async {
    final formKey = GlobalKey<FormState>();
    final amountController = TextEditingController();
    final dateController = TextEditingController();
    final notesController = TextEditingController();

    int? selectedAccountId;
    int? selectedCategoryId;
    List<Map<String, dynamic>> categories = [];
    List<Map<String, dynamic>> accounts = [];
    bool isLoading = true;
    String? loadError;

    // Set today's date as default
    dateController.text = DateTime.now().toString().split(' ')[0];

    print('$TAG: _showTransactionPopup started for type: $type');

    await showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => StatefulBuilder(
        builder: (context, setState) {
          // Load data when dialog opens
          if (isLoading) {
            print('$TAG: Loading transaction data...');
            _loadTransactionData(type).then((result) {
              setState(() {
                isLoading = false;
                result.fold(
                  (error) {
                    loadError = error;
                    print('$TAG: Error loading data: $error');
                  },
                  (data) {
                    categories = data['categories']!;
                    accounts = data['accounts']!;
                    print(
                      '$TAG: Data loaded successfully. Accounts: ${accounts.length}, Categories: ${categories.length}',
                    );
                  },
                );
              });
            });
          }

          return AlertDialog(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16),
            ),
            title: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: type == 'income'
                        ? Colors.green.withOpacity(0.1)
                        : Colors.red.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Icon(
                    type == 'income' ? Icons.add_circle : Icons.remove_circle,
                    color: type == 'income' ? Colors.green : Colors.red,
                    size: 24,
                  ),
                ),
                const SizedBox(width: 12),
                Text('Add ${type.toUpperCase()}'),
              ],
            ),
            content: SizedBox(
              width: MediaQuery.of(context).size.width * 0.8,
              child: isLoading
                  ? const Center(
                      child: Padding(
                        padding: EdgeInsets.all(32),
                        child: CircularProgressIndicator(),
                      ),
                    )
                  : loadError != null
                  ? Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.error, color: Colors.red, size: 48),
                          const SizedBox(height: 16),
                          Text('Error: $loadError'),
                          const SizedBox(height: 16),
                          ElevatedButton(
                            onPressed: () {
                              setState(() {
                                isLoading = true;
                                loadError = null;
                              });
                            },
                            child: const Text('Retry'),
                          ),
                        ],
                      ),
                    )
                  : Form(
                      key: formKey,
                      child: SingleChildScrollView(
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            _buildTextFormField(
                              controller: amountController,
                              label: 'Amount',
                              icon: Icons.attach_money,
                              keyboardType:
                                  const TextInputType.numberWithOptions(
                                    decimal: true,
                                  ),
                              inputFormatters: [
                                FilteringTextInputFormatter.allow(
                                  RegExp(r'^\d*\.?\d{0,2}'),
                                ),
                              ],
                              validator: (value) {
                                if (value?.isEmpty ?? true) {
                                  return 'Amount is required';
                                }
                                final amount = double.tryParse(value!);
                                if (amount == null) {
                                  return 'Enter a valid amount';
                                }
                                if (amount <= 0) {
                                  return 'Amount must be greater than 0';
                                }
                                if (amount > 999999999) {
                                  return 'Amount is too large';
                                }
                                return null;
                              },
                            ),
                            const SizedBox(height: 16),
                            _buildDateField(
                              controller: dateController,
                              label: 'Date',
                              context: context,
                              validator: (value) {
                                if (value?.isEmpty ?? true) {
                                  return 'Date is required';
                                }
                                final date = DateTime.tryParse(value!);
                                if (date == null) {
                                  return 'Enter a valid date';
                                }
                                if (date.isAfter(DateTime.now())) {
                                  return 'Date cannot be in the future';
                                }
                                return null;
                              },
                            ),
                            const SizedBox(height: 16),
                            _buildDropdownField<int>(
                              value: selectedAccountId,
                              label: 'Account',
                              icon: Icons.account_balance_outlined,
                              items: accounts
                                  .map(
                                    (acc) => DropdownMenuItem<int>(
                                      value: acc['id'] as int,
                                      child: Text(acc['name'].toString()),
                                    ),
                                  )
                                  .toList(),
                              onChanged: (val) => selectedAccountId = val,
                              validator: (value) {
                                if (value == null) {
                                  return 'Please select an account';
                                }
                                return null;
                              },
                            ),
                            const SizedBox(height: 16),
                            _buildDropdownField<int>(
                              value: selectedCategoryId,
                              label: 'Category',
                              icon: Icons.edit_note_sharp,
                              items: categories
                                  .map(
                                    (cat) => DropdownMenuItem<int>(
                                      value: cat['id'] as int,
                                      child: Text(cat['name'].toString()),
                                    ),
                                  )
                                  .toList(),
                              onChanged: (val) => selectedCategoryId = val,
                              validator: (value) {
                                if (value == null) {
                                  return 'Please select a category';
                                }
                                return null;
                              },
                            ),
                            const SizedBox(height: 16),
                            _buildTextFormField(
                              controller: notesController,
                              label: 'Notes (Optional)',
                              icon: Icons.note,
                              maxLines: 3,
                              validator: (value) {
                                if (value != null && value.length > 500) {
                                  return 'Notes cannot exceed 500 characters';
                                }
                                return null;
                              },
                            ),
                          ],
                        ),
                      ),
                    ),
            ),
            actions: [
              TextButton(
                onPressed: () {
                  print('$TAG: Cancel button pressed. Dismissing dialog.');
                  Navigator.pop(context);
                },
                child: const Text('Cancel'),
              ),
              ElevatedButton(
                onPressed: isLoading || loadError != null
                    ? null
                    : () async {
                        print('$TAG: Save button pressed. Type: $type');
                        if (formKey.currentState?.validate() ?? false) {
                          try {
                            if (type == 'expense') {
                              final expenseAmount = double.parse(
                                amountController.text,
                              );
                              final transactionDate = dateController.text;

                              print('$TAG: --- Expense Transaction Checks ---');
                              print(
                                '$TAG: Amount: $expenseAmount, Date: $transactionDate, Account ID: $selectedAccountId',
                              );

                              // Check overall balance
                              final balanceCheckResult =
                                  await _checkSufficientBalance(expenseAmount);

                              balanceCheckResult.fold(
                                (error) {
                                  print(
                                    '$TAG: Balance check FAILED. Reason: $error',
                                  );
                                  Navigator.pop(context);
                                  GetIt.I<NavigationService>()
                                      .showErrorSnackbar(
                                        title: 'Insufficient Balance',
                                        body: error,
                                      );
                                },
                                (r) {
                                  print('$TAG: Balance check PASSED.');
                                },
                              );

                              if (balanceCheckResult.isLeft()) return;

                              // Check budget constraint
                              final budgetCheckResult =
                                  await _checkBudgetConstraint(
                                    selectedAccountId!,
                                    expenseAmount,
                                    transactionDate,
                                  );

                              budgetCheckResult.fold(
                                (error) {
                                  print(
                                    '$TAG: Budget check FAILED. Reason: $error',
                                  );
                                  Navigator.pop(context);
                                  GetIt.I<NavigationService>()
                                      .showErrorSnackbar(
                                        title: 'Budget Exceeded',
                                        body: error,
                                      );
                                },
                                (r) {
                                  print('$TAG: Budget check PASSED.');
                                },
                              );

                              if (budgetCheckResult.isLeft()) return;
                            }

                            // If all checks pass, proceed with insertion
                            print(
                              '$TAG: All checks passed. Inserting transaction...',
                            );
                            await _db.insert('transactions', {
                              'amount': double.parse(amountController.text),
                              'date': dateController.text,
                              'type': type,
                              'notes': notesController.text.trim(),
                              'account_id': selectedAccountId,
                              'category_id': selectedCategoryId,
                            });

                            print('$TAG: Transaction successfully inserted.');
                            Navigator.pop(context);
                            _showSuccessSnackBar(
                              context,
                              '${type.toUpperCase()} added successfully!',
                            );
                          } catch (error) {
                            print(
                              '$TAG: Unexpected error during transaction save: $error',
                            );
                            _showErrorSnackBar(
                              context,
                              'Failed to add $type: $error',
                            );
                          }
                        }
                      },
                style: ElevatedButton.styleFrom(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
                child: Text('Save ${type.toUpperCase()}'),
              ),
            ],
          );
        },
      ),
    );
  }

  /// Check if there's sufficient balance for the expense using HomeRepository
  Future<Either<String, bool>> _checkSufficientBalance(
    double expenseAmount,
  ) async {
    try {
      // Get total income and expenses using HomeRepository methods
      final totalIncome = await _homeRepository.getTotalIncome();
      final totalExpense = await _homeRepository.getTotalExpense();

      // Calculate current balance
      final currentBalance = totalIncome - totalExpense;

      print(
        '$TAG: _checkSufficientBalance called. Current Balance: $currentBalance, Expense Amount: $expenseAmount',
      );

      // Check if current balance minus the new expense would be negative
      final balanceAfterExpense = currentBalance - expenseAmount;

      if (balanceAfterExpense < 0) {
        print('$TAG: Balance check failed. Not enough funds.');
        return Left(
          'Current balance: \$${currentBalance.toStringAsFixed(2)}\n'
          'Expense amount: \$${expenseAmount.toStringAsFixed(2)}\n'
          'Balance after expense: \$${balanceAfterExpense.toStringAsFixed(2)}\n\n'
          'Please add more income or reduce the expense amount.',
        );
      }
      print('$TAG: Balance is sufficient.');
      return const Right(true);
    } catch (error) {
      print('$TAG: Error checking balance: $error');
      return Left('Error checking balance: $error');
    }
  }

  /// Check if the expense would exceed the budget for the selected account
  Future<Either<String, bool>> _checkBudgetConstraint(
    int accountId,
    double expenseAmount,
    String transactionDate,
  ) async {
    try {
      print(
        '$TAG: _checkBudgetConstraint called for Account ID: $accountId, Expense: $expenseAmount, Date: $transactionDate',
      );

      // Parse the transaction date
      final DateTime? transactionDateTime = DateTime.tryParse(transactionDate);
      if (transactionDateTime == null) {
        print('$TAG: Invalid transaction date format.');
        return Left('Invalid transaction date format.');
      }

      // Get active budgets for this account that include the transaction date
      final budgetResult = await _db.getBudgetsForAccount(
        accountId,
        transactionDate,
      );

      print('$TAG: Budget query result: $budgetResult');

      // If no budget exists for this account and date, allow the transaction
      if (budgetResult.isLeft()) {
        print('$TAG: Budget query failed. Allowing transaction.');
        return const Right(true);
      }

      final budgets = budgetResult.fold(
        (l) => <Map<String, dynamic>>[],
        (r) => r,
      );
      if (budgets.isEmpty) {
        print(
          '$TAG: No budgets found for this account and date. Allowing transaction.',
        );
        return const Right(true);
      }

      // Check each applicable budget (there might be multiple overlapping budgets)
      for (final budget in budgets) {
        final budgetAmount = (budget['amount'] as num).toDouble();
        final startDate = budget['start_date'] as String;
        final endDate = budget['end_date'] as String;

        print(
          '$TAG: Found budget. ID: ${budget['id']}, Amount: $budgetAmount, Dates: $startDate to $endDate',
        );

        // Get total expenses for this account within the budget period
        final expensesResult = await _db.complexQuery(
          table: 'transactions',
          columns: ['SUM(amount) as total_expenses'],
          where: 'account_id = ? AND type = ? AND date BETWEEN ? AND ?',
          whereArgs: [accountId, 'expense', startDate, endDate],
        );

        print('$TAG: Expenses query result for this budget: $expensesResult');

        double currentExpenses = 0.0;
        expensesResult.fold(
          (error) {
            print('$TAG: Error querying current expenses: $error');
            currentExpenses = 0.0;
          },
          (data) {
            if (data.isNotEmpty && data.first['total_expenses'] != null) {
              currentExpenses = (data.first['total_expenses'] as num)
                  .toDouble();
              print(
                '$TAG: Current expenses within budget period: $currentExpenses',
              );
            }
          },
        );

        // Check if adding this expense would exceed the budget
        final totalAfterExpense = currentExpenses + expenseAmount;
        print(
          '$TAG: Total expenses after new expense: $totalAfterExpense. Budget limit: $budgetAmount',
        );

        if (totalAfterExpense > budgetAmount) {
          print('$TAG: Budget exceeded! Denying transaction.');
          // Get account name for better error message
          final accountResult = await _db.complexQuery(
            table: 'accounts',
            columns: ['name'],
            where: 'id = ?',
            whereArgs: [accountId],
          );

          String accountName = 'Selected Account';
          accountResult.fold((error) {}, (data) {
            if (data.isNotEmpty && data.first['name'] != null) {
              accountName = data.first['name'] as String;
            }
          });
          return Left('لقد قمت بتجاوز الحد الاقصى للميزانية من هذا الحساب');
          // return Left(
          //   'Budget limit exceeded for $accountName!\n\n'
          //   'Budget period: $startDate to $endDate\n'
          //   'Budget limit: \$${budgetAmount.toStringAsFixed(2)}\n'
          //   'Current expenses: \$${currentExpenses.toStringAsFixed(2)}\n'
          //   'This expense: \$${expenseAmount.toStringAsFixed(2)}\n'
          //   'Total after expense: \$${totalAfterExpense.toStringAsFixed(2)}\n\n'
          //   'You would exceed the budget by \$${(totalAfterExpense - budgetAmount).toStringAsFixed(2)}',
          // );
        }
      }

      print('$TAG: All budget checks passed. Allowing transaction.');
      return const Right(true);
    } catch (error) {
      print('$TAG: Unexpected error in _checkBudgetConstraint: $error');
      return Left('Error checking budget constraint: $error');
    }
  }

  Future<Either<String, Map<String, List<Map<String, dynamic>>>>>
  _loadTransactionData(String type) async {
    try {
      // Load categories for this type
      final catsResult = await _db.queryRow('categories', 'type = ?', [type]);
      List<Map<String, dynamic>> categories = [];
      catsResult.fold((_) {}, (data) => categories = data);

      // Load all accounts
      final accResult = await _db.queryRow('accounts', '1=?', [1]);
      List<Map<String, dynamic>> accounts = [];
      accResult.fold((_) {}, (data) => accounts = data);

      if (accounts.isEmpty) {
        return const Left('No accounts found. Please create an account first.');
      }

      if (categories.isEmpty) {
        return Left(
          'No $type categories found. Please create categories first.',
        );
      }

      return Right({'categories': categories, 'accounts': accounts});
    } catch (error) {
      return Left('Failed to load data: $error');
    }
  }

  Widget _buildTextFormField({
    required TextEditingController controller,
    required String label,
    required IconData icon,
    TextInputType? keyboardType,
    List<TextInputFormatter>? inputFormatters,
    String? Function(String?)? validator,
    int maxLines = 1,
  }) {
    return TextFormField(
      controller: controller,
      decoration: InputDecoration(
        labelText: label,
        prefixIcon: Icon(icon, color: ColorManager.primary),

        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: Colors.grey.shade300),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: Colors.blue, width: 2),
        ),
        errorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: Colors.red),
        ),
        contentPadding: const EdgeInsets.symmetric(
          horizontal: 16,
          vertical: 12,
        ),
      ),
      keyboardType: keyboardType,
      inputFormatters: inputFormatters,
      validator: validator,
      maxLines: maxLines,
    );
  }

  Widget _buildDateField({
    required TextEditingController controller,
    required String label,
    required BuildContext context,
    String? Function(String?)? validator,
  }) {
    return TextFormField(
      controller: controller,
      decoration: InputDecoration(
        labelText: label,
        prefixIcon: const Icon(
          Icons.calendar_today,
          color: ColorManager.primary,
        ),
        suffixIcon: IconButton(
          icon: const Icon(Icons.date_range),
          onPressed: () async {
            final date = await showDatePicker(
              context: context,
              initialDate: DateTime.now(),
              firstDate: DateTime(2000),
              lastDate: DateTime.now(),
            );
            if (date != null) {
              controller.text = date.toString().split(' ')[0];
            }
          },
        ),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: Colors.grey.shade300),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: Colors.blue, width: 2),
        ),
        errorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: Colors.red),
        ),
        contentPadding: const EdgeInsets.symmetric(
          horizontal: 16,
          vertical: 12,
        ),
      ),
      readOnly: true,
      validator: validator,
    );
  }

  Widget _buildDropdownField<T>({
    required T? value,
    required String label,
    required IconData icon,
    required List<DropdownMenuItem<T>> items,
    required void Function(T?) onChanged,
    String? Function(T?)? validator,
  }) {
    return DropdownButtonFormField<T>(
      value: value,
      decoration: InputDecoration(
        labelText: label,
        prefixIcon: Icon(icon, color: ColorManager.primary),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: Colors.grey.shade300),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: Colors.blue, width: 2),
        ),
        errorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: Colors.red),
        ),
        contentPadding: const EdgeInsets.symmetric(
          horizontal: 16,
          vertical: 12,
        ),
      ),
      items: items,
      onChanged: onChanged,
      validator: validator,
      isExpanded: true,
    );
  }

  void _showSuccessSnackBar(BuildContext context, String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            const Icon(Icons.check_circle, color: Colors.white),
            const SizedBox(width: 8),
            Text(message),
          ],
        ),
        backgroundColor: Colors.green,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
      ),
    );
  }

  void _showErrorSnackBar(BuildContext context, String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            const Icon(Icons.error, color: Colors.white),
            const SizedBox(width: 8),
            Expanded(child: Text(message)),
          ],
        ),
        backgroundColor: Colors.red,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
        duration: const Duration(seconds: 4),
      ),
    );
  }
}
