import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:mudabbir/constants/hive_constants.dart';
import 'package:mudabbir/persentation/register/register_viewmodel.dart';
import 'package:mudabbir/service/getit_init.dart';
import 'package:mudabbir/service/hive_service.dart';
import 'package:mudabbir/service/navigation_service.dart';
import 'package:mudabbir/service/routing_service/auth_notifier.dart';

class RegisterView extends ConsumerWidget {
  RegisterView({super.key});

  // Controllers
  final _firstNameController = TextEditingController();
  // todo: lastname
  // final _lastNameController = TextEditingController();
  final _emailController = TextEditingController();
  // todo : phone number
  // final _phoneController = TextEditingController();
  final _passwordController = TextEditingController();
  final _confirmPasswordController = TextEditingController();

  // Key for validation
  final _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final registerState = ref.watch(registerProvider);
    final registerViewModel = ref.read(registerProvider.notifier);

    ref.listen<RegisterState>(registerProvider, (
      previousState,
      newState,
    ) async {
      if (newState.failure != null) {
        getIt<NavigationService>().showErrorSnackbar(
          title: 'Error',
          body: newState.failure!.message,
        );
      } else if (newState.user != null && !newState.isLoading) {
        try {
          getIt<NavigationService>().showSuccessSnackbar(
            title: 'Success',
            body: 'You are logged in',
          );

          // 1. Get the user data from the state.
          final userModel = newState.user!;
          final userMap = {'name': userModel.name, 'email': userModel.email};

          // 2. Read the token that the ApiService just saved to Hive.
          final token = getIt<HiveService>().getValue(HiveConstants.savedToken);

          // 3. Check if the token was actually found before proceeding.
          if (token != null) {
            // 4. Call didLogin and wait for it to complete
            await getIt<AuthNotifier>().didLogin(userMap, token);

            // 5. Optional: Force a small delay to ensure GoRouter processes the state change
            await Future.delayed(const Duration(milliseconds: 100));

            print('Login completed successfully');
          } else {
            // Handle the unlikely case that the token wasn't saved correctly.
            getIt<NavigationService>().showErrorSnackbar(
              title: 'Error',
              body: 'Login session could not be created. Please try again.',
            );
          }
        } catch (e) {
          print('Error during login process: $e');
          getIt<NavigationService>().showErrorSnackbar(
            title: 'Error',
            body: 'An error occurred during login. Please try again.',
          );
        }
      }
    });

    return Scaffold(
      appBar: AppBar(title: const Text("Register")),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              TextFormField(
                controller: _firstNameController,
                decoration: const InputDecoration(labelText: "First Name"),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return "Please enter your first name";
                  }
                  return null;
                },
              ),
              const SizedBox(height: 12),

              // TextFormField(
              //   controller: _lastNameController,
              //   decoration: const InputDecoration(labelText: "Last Name"),
              //   validator: (value) {
              //     if (value == null || value.isEmpty) {
              //       return "Please enter your last name";
              //     }
              //     return null;
              //   },
              // ),
              // const SizedBox(height: 12),
              TextFormField(
                controller: _emailController,
                decoration: const InputDecoration(labelText: "Email"),
                keyboardType: TextInputType.emailAddress,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return "Please enter your email";
                  }
                  if (!RegExp(r'^[^@]+@[^@]+\.[^@]+').hasMatch(value)) {
                    return "Please enter a valid email";
                  }
                  return null;
                },
              ),
              const SizedBox(height: 12),

              // Saudi Phone Number Field
              // TextFormField(
              //   controller: _phoneController,
              //   decoration: const InputDecoration(labelText: "Phone Number"),
              //   keyboardType: TextInputType.phone,
              //   validator: (value) {
              //     if (value == null || value.isEmpty) {
              //       return "Please enter your phone number";
              //     }
              //     // Saudi number: starts with 05 and 10 digits total
              //     if (!RegExp(r'^05\d{8}$').hasMatch(value)) {
              //       return "Please enter a valid Saudi phone number";
              //     }
              //     return null;
              //   },
              // ),
              // const SizedBox(height: 12),
              TextFormField(
                controller: _passwordController,
                decoration: const InputDecoration(labelText: "Password"),
                obscureText: true,
                validator: (value) {
                  if (value == null || value.length < 6) {
                    return "Password must be at least 6 characters";
                  }
                  return null;
                },
              ),
              const SizedBox(height: 12),

              TextFormField(
                controller: _confirmPasswordController,
                decoration: const InputDecoration(
                  labelText: "Confirm Password",
                ),
                obscureText: true,
                validator: (value) {
                  if (value != _passwordController.text) {
                    return "Passwords do not match";
                  }
                  return null;
                },
              ),
              const SizedBox(height: 20),

              registerState.isLoading
                  ? Center(child: CircularProgressIndicator())
                  : ElevatedButton(
                      onPressed: () {
                        if (_formKey.currentState!.validate()) {
                          registerViewModel.register(
                            _firstNameController.text,
                            _emailController.text,
                            _passwordController.text,
                            _confirmPasswordController.text,
                          );
                        }
                      },
                      child: const Text(
                        "Register",
                        style: TextStyle(
                          fontSize: 18,
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
              const SizedBox(height: 10),
              OutlinedButton(
                onPressed: () {
                  context.go('/login');
                },
                child: const Text("Already have an account? Login"),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
