import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:mudabbir/constants/hive_constants.dart';
import 'package:mudabbir/data/local/database_helper.dart';
import 'package:mudabbir/persentation/budget/budget_view.dart';
import 'package:mudabbir/persentation/home/widgets/add_container.dart';
import 'package:mudabbir/persentation/home/widgets/summary_widget.dart';
import 'package:mudabbir/persentation/resources/assets_manager.dart';
import 'package:mudabbir/persentation/resources/color_manager.dart';
import 'package:mudabbir/persentation/resources/strings_manager.dart';
import 'package:mudabbir/service/getit_init.dart';
import 'package:mudabbir/service/hive_service.dart';
import 'package:mudabbir/service/navigation_service.dart';
import 'package:mudabbir/service/routing_service/auth_notifier.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});
  //seeding database method
  // Future<void> seedDatabase(DbHelper dbHelper) async {
  //   print('--- Seeding Database ---');
  //
  //   // Get the raw database instance to use a transaction
  //   final db = await dbHelper.database;
  //
  //   // 1. Use a transaction for an "all or nothing" operation
  //   await db.transaction((txn) async {
  //     // 2. Clear existing data (in reverse order of dependencies)
  //     await txn.delete('transactions');
  //     await txn.delete('budgets');
  //     await txn.delete('accounts');
  //     await txn.delete('categories');
  //     await txn.delete('goals');
  //     await txn.delete('challenges');
  //
  //     // 3. Insert Accounts and get their IDs
  //     int cashAccountId = await txn.insert('accounts', {
  //       'name': 'Cash',
  //       'balance': 550.75,
  //     });
  //     int bankAccountId = await txn.insert('accounts', {
  //       'name': 'Bank Account',
  //       'balance': 4350.25,
  //     });
  //     int savingsAccountId = await txn.insert('accounts', {
  //       'name': 'Savings',
  //       'balance': 12500.00,
  //     });
  //
  //     // 4. Insert Categories and get their IDs
  //     // Expenses
  //     int groceriesCatId = await txn.insert('categories', {
  //       'name': 'Groceries',
  //       'type': 'expense',
  //     });
  //     int transportCatId = await txn.insert('categories', {
  //       'name': 'Transport',
  //       'type': 'expense',
  //     });
  //     int entertainmentCatId = await txn.insert('categories', {
  //       'name': 'Entertainment',
  //       'type': 'expense',
  //     });
  //     // Income
  //     int salaryCatId = await txn.insert('categories', {
  //       'name': 'Salary',
  //       'type': 'income',
  //     });
  //     int freelanceCatId = await txn.insert('categories', {
  //       'name': 'Freelance',
  //       'type': 'income',
  //     });
  //
  //     // 5. Insert Transactions using the IDs from above
  //     // Income
  //     await txn.insert('transactions', {
  //       'amount': 2300.00,
  //       'date': '2025-09-01T10:00:00Z',
  //       'type': 'income',
  //       'notes': 'Monthly salary',
  //       'account_id': bankAccountId,
  //       'category_id': salaryCatId,
  //     });
  //     // Expenses
  //     await txn.insert('transactions', {
  //       'amount': 400,
  //       'date': '2025-09-02T18:30:00Z',
  //       'type': 'expense',
  //       'notes': 'Weekly groceries',
  //       'account_id': bankAccountId,
  //       'category_id': groceriesCatId,
  //     });
  //     await txn.insert('transactions', {
  //       'amount': 600.00,
  //       'date': '2025-09-05T20:00:00Z',
  //       'type': 'expense',
  //       'notes': 'Movie tickets',
  //       'account_id': cashAccountId,
  //       'category_id': entertainmentCatId,
  //     });
  //     await txn.insert('transactions', {
  //       'amount': 40.00,
  //       'date': '2025-09-10T08:00:00Z',
  //       'type': 'expense',
  //       'notes': 'Gas for car',
  //       'account_id': bankAccountId,
  //       'category_id': transportCatId,
  //     });
  //
  //     // 6. Insert Goals, Budgets, and Challenges
  //     await txn.insert('goals', {
  //       'name': 'Vacation to Italy',
  //       'target': 4000.00,
  //       'current_amount': 750.00,
  //       'type': 'Savings',
  //       'start_date': '2025-01-01T00:00:00Z',
  //       'end_date': '2026-06-01T00:00:00Z',
  //     });
  //
  //     await txn.insert('budgets', {
  //       'amount': 500.00,
  //       'start_date': '2025-09-01T00:00:00Z',
  //       'end_date': '2025-09-30T23:59:59Z',
  //       'account_id': bankAccountId,
  //     });
  //
  //     await txn.insert('challenges', {
  //       'name': 'No Spend September',
  //       'start_date': '2025-09-01T00:00:00Z',
  //       'end_date': '2025-09-30T23:59:59Z',
  //       'status': 'In Progress',
  //     });
  //   });
  //
  //   print('--- Database Seeding Complete ---');
  // }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // seeding database
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          try {
            getIt<DbHelper>().insert('budgets', {
              'amount': 1500,
              'start_date': '2025-09-16', // Corrected: Added a leading zero
              'end_date': '2025-09-22', // Corrected: Added a leading zero
              'account_id': 1,
            });
            getIt<DbHelper>().insert('budgets', {
              'amount': 2000,
              'start_date': '2025-09-16', // Corrected: Added a leading zero
              'end_date': '2025-09-22', // Corrected: Added a leading zero
              'account_id': 2,
            });
            getIt<DbHelper>().insert('budgets', {
              'amount': 3000,
              'start_date': '2025-09-16', // Corrected: Added a leading zero
              'end_date': '2025-09-22', // Corrected: Added a leading zero
              'account_id': 2,
            });
            getIt<DbHelper>().insert('budgets', {
              'amount': 4000,
              'start_date': '2025-09-16', // Corrected: Added a leading zero
              'end_date': '2025-09-22', // Corrected: Added a leading zero
              'account_id': 2,
            });
            print('successfull');
          } catch (error) {
            print(error);
          }
        },
      ),
      backgroundColor: Color(0xfff6f5f5),
      appBar: AppBar(
        // backgroundColor: Color(0xfff6f5f5),
        backgroundColor: ColorManager.primary,
        elevation: 0,
        title: Row(
          children: [
            SvgPicture.asset(
              ImageAssets.onBoardingLogo1,
              fit: BoxFit.contain,
              width: 30,
              height: 30,
            ),
            SizedBox(width: 10),
            Text(
              '${AppStrings.title} - ${getIt<HiveService>().getValue(HiveConstants.savedUserInfo)['name']}',
              style: Theme.of(context).textTheme.headlineLarge,
            ),
          ],
        ),
        centerTitle: false,
        actions: [
          IconButton(
            onPressed: () async {
              await getIt<AuthNotifier>().didLogout();
            },
            icon: Icon(Icons.login),
          ),
        ],
      ),
      body: Container(
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(height: 20),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Text(
                  AppStrings.homeText1,
                  style: Theme.of(context).textTheme.headlineSmall,
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Text(
                  AppStrings.homeText2,
                  style: Theme.of(context).textTheme.headlineSmall,
                ),
              ),
              SizedBox(height: 10),
              SummaryWidget(),
              SizedBox(height: 10),
              // add widget
              AddContainer(),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Text(
                  AppStrings.yourStat,
                  style: Theme.of(context).textTheme.headlineSmall,
                ),
              ),
              SizedBox(height: 10),
              // StatisticsWidget(),
              Container(
                height: 100,
                margin: EdgeInsets.all(10),
                padding: EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: ColorManager.primary,
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(20),
                    bottomRight: Radius.circular(20),
                    topRight: Radius.circular(20),
                    bottomLeft: Radius.circular(20),
                  ),
                ),
                child: InkWell(
                  onTap: () {},
                  child: Row(
                    children: [
                      SvgPicture.asset(
                        ImageAssets.onBoardingLogo2,
                        fit: BoxFit.contain,
                        width: 60,
                        height: 60,
                      ),
                      SizedBox(width: 10),
                      Expanded(
                        child: Text(
                          AppStrings.StatisticsString,
                          style: Theme.of(context).textTheme.headlineLarge,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              SizedBox(height: 10),

              // StatisticsWidget(),
              Container(
                height: 100,
                margin: EdgeInsets.all(10),
                padding: EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: ColorManager.white,
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(20),
                    bottomRight: Radius.circular(20),
                    topRight: Radius.circular(20),
                    bottomLeft: Radius.circular(20),
                  ),
                ),
                child: InkWell(
                  onTap: () {
                    getIt<NavigationService>().navigate(BudgetView());
                  },
                  child: Row(
                    children: [
                      SvgPicture.asset(
                        ImageAssets.onBoardingLogo2,
                        fit: BoxFit.contain,
                        width: 60,
                        height: 60,
                      ),
                      SizedBox(width: 10),
                      Expanded(
                        child: Text(
                          AppStrings.budgetString,
                          style: Theme.of(context).textTheme.headlineSmall,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
