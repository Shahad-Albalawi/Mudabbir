import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:mudabbir/persentation/home/home_viewmodel.dart';
import 'package:mudabbir/persentation/resources/color_manager.dart';
import 'package:mudabbir/persentation/resources/strings_manager.dart';

class SummaryWidget extends ConsumerWidget {
  const SummaryWidget({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final homeState = ref.watch(homeProvider);
    final homeViewModel = ref.read(homeProvider.notifier);
    homeViewModel.loadFinancialSummary();
    return Container(
      height: 120,
      width: double.infinity,
      margin: EdgeInsets.all(10),
      padding: EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: ColorManager.primary,
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(20),
          bottomRight: Radius.circular(20),
          topRight: Radius.circular(20),
          bottomLeft: Radius.circular(20),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          Text(
            '${AppStrings.totalIncome} ${homeState.totalIncome} ',
            style: Theme.of(context).textTheme.headlineMedium,
          ),
          Text(
            '${AppStrings.currentBalance} ${homeState.currentBalance} ',
            style: Theme.of(context).textTheme.headlineMedium,
          ),
          Text(
            '${AppStrings.totalExpense} ${homeState.totalExpense} ',
            style: Theme.of(context).textTheme.headlineMedium,
          ),
        ],
      ),
    );
  }
}
