import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:mudabbir/persentation/home/home_viewmodel.dart';
import 'package:mudabbir/persentation/resources/color_manager.dart';
import 'package:mudabbir/persentation/resources/strings_manager.dart';
import 'package:mudabbir/service/getit_init.dart';
import 'package:mudabbir/service/popup_service/popup_service.dart';

class AddContainer extends ConsumerWidget {
  const AddContainer({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final homeViewModel = ref.read(homeProvider.notifier);
    return Container(
      margin: EdgeInsets.all(10),
      padding: EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: ColorManager.white,
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(20),
          bottomRight: Radius.circular(20),
          topRight: Radius.circular(20),
          bottomLeft: Radius.circular(20),
        ),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          Column(
            children: [
              Text(
                '${AppStrings.addExpense}',
                style: Theme.of(context).textTheme.headlineSmall,
              ),
              IconButton(
                onPressed: () {
                  getIt<PopupService>().showAddExpensePopup(context);
                  homeViewModel.loadFinancialSummary();
                },
                icon: Icon(Icons.add, color: Colors.green, size: 30),
              ),
            ],
          ),
          Column(
            children: [
              Text(
                '${AppStrings.addIncome}',
                style: Theme.of(context).textTheme.headlineSmall,
              ),
              IconButton(
                onPressed: () {
                  getIt<PopupService>().showAddIncomePopup(context);
                  homeViewModel.loadFinancialSummary();
                },
                icon: Icon(Icons.add, color: Colors.green, size: 30),
              ),
            ],
          ),
          Column(
            children: [
              Text(
                '${AppStrings.addChallenge}',
                style: Theme.of(context).textTheme.headlineSmall,
              ),
              IconButton(
                onPressed: () {},
                icon: Icon(Icons.add, color: Colors.green, size: 30),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
