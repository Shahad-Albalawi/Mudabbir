import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:mudabbir/constants/hive_constants.dart';
import 'package:mudabbir/data/local/local_database.dart';
import 'package:mudabbir/domain/repository/home_repository/home_repository.dart';
import 'package:mudabbir/service/getit_init.dart';
import 'package:mudabbir/service/hive_service.dart';

class HomeState {
  double totalIncome = 0;
  double totalExpense = 0;
  double currentBalance = 0;
  HomeState({
    required this.totalIncome,
    required this.totalExpense,
    required this.currentBalance,
  });
  HomeState copyWith({
    double? totalIncome,
    double? totalExpense,
    double? currentBalance,
  }) {
    return HomeState(
      totalIncome: totalIncome ?? this.totalIncome,
      totalExpense: totalExpense ?? this.totalExpense,
      currentBalance: currentBalance ?? this.currentBalance,
    );
  }
}

final homeProvider = StateNotifierProvider<HomeViewModel, HomeState>(
  (_) => HomeViewModel(),
);

class HomeViewModel extends StateNotifier<HomeState> {
  HomeViewModel()
    : super(HomeState(totalIncome: 0, totalExpense: 0, currentBalance: 0)) {
    loadFinancialSummary();
  }

  final HomeRepository homeRepository = getIt<HomeRepository>();

  loadFinancialSummary() async {
    final user = await getIt<HiveService>().getValue(
      HiveConstants.savedUserInfo,
    );
    await LocalDatabase.instance.initForUser(user['name']);
    final income = await homeRepository.getTotalIncome();
    final expense = await homeRepository.getTotalExpense();
    state = state.copyWith(
      totalIncome: income,
      totalExpense: expense,
      currentBalance: income - expense,
    );
  }
}
