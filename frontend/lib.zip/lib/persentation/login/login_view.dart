import 'package:go_router/go_router.dart';
import 'package:mudabbir/constants/hive_constants.dart';
import 'package:mudabbir/persentation/login/login_viewmodel.dart';
import 'package:mudabbir/service/getit_init.dart';
import 'package:mudabbir/service/hive_service.dart';
import 'package:mudabbir/service/navigation_service.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:mudabbir/service/routing_service/auth_notifier.dart';
import '../resources/color_manager.dart';

class LoginView extends ConsumerWidget {
  LoginView({super.key});
  final emailController = TextEditingController();
  final passwordController = TextEditingController();
  final formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final loginState = ref.watch(loginProvider);
    final loginViewModel = ref.read(loginProvider.notifier);

    // Updated listener in LoginView
    ref.listen<LoginState>(loginProvider, (previousState, newState) async {
      if (newState.failure != null) {
        getIt<NavigationService>().showErrorSnackbar(
          title: 'Error',
          body: newState.failure!.message,
        );
      } else if (newState.user != null && !newState.isLoading) {
        try {
          getIt<NavigationService>().showSuccessSnackbar(
            title: 'Success',
            body: 'You are logged in',
          );

          // 1. Get the user data from the state.
          final userModel = newState.user!;
          final userMap = {'name': userModel.name, 'email': userModel.email};

          // 2. Read the token that the ApiService just saved to Hive.
          final token = getIt<HiveService>().getValue(HiveConstants.savedToken);

          // 3. Check if the token was actually found before proceeding.
          if (token != null) {
            // 4. Call didLogin and wait for it to complete
            await getIt<AuthNotifier>().didLogin(userMap, token);

            // 5. Optional: Force a small delay to ensure GoRouter processes the state change
            await Future.delayed(const Duration(milliseconds: 100));

            print('Login completed successfully');
          } else {
            // Handle the unlikely case that the token wasn't saved correctly.
            getIt<NavigationService>().showErrorSnackbar(
              title: 'Error',
              body: 'Login session could not be created. Please try again.',
            );
          }
        } catch (e) {
          print('Error during login process: $e');
          getIt<NavigationService>().showErrorSnackbar(
            title: 'Error',
            body: 'An error occurred during login. Please try again.',
          );
        }
      }
    });
    return Scaffold(
      floatingActionButton: FloatingActionButton(onPressed: () async {}),
      backgroundColor: ColorManager.background,
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 24),
          child: Form(
            key: formKey,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // Logo or title
                ListView.builder(
                  shrinkWrap: true,
                  itemCount: 4,
                  itemBuilder: (context, index) {
                    return Text('hello world');
                  },
                ),
                const SizedBox(height: 32),

                // Email Field
                TextFormField(
                  controller: emailController,
                  keyboardType: TextInputType.emailAddress,
                  decoration: InputDecoration(
                    hintText: 'Email',
                    prefixIcon: const Icon(Icons.email_outlined),
                    filled: true,
                    fillColor: ColorManager.white,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: BorderSide.none,
                    ),
                  ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Email cannot be empty';
                    }
                    if (!RegExp(r'\S+@\S+\.\S+').hasMatch(value)) {
                      return 'Enter a valid email';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 16),

                // Password Field
                TextFormField(
                  controller: passwordController,
                  obscureText: true,
                  decoration: InputDecoration(
                    hintText: 'Password',
                    prefixIcon: const Icon(Icons.lock_outline),
                    filled: true,
                    fillColor: ColorManager.white,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: BorderSide.none,
                    ),
                  ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Password cannot be empty';
                    }
                    if (value.length < 6) {
                      return 'Password must be at least 6 characters';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 24),

                // Login Button
                SizedBox(
                  width: double.infinity,
                  height: 50,
                  child: loginState.isLoading
                      ? Center(child: CircularProgressIndicator())
                      : ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: ColorManager.primary,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                            elevation: 5,
                            shadowColor: ColorManager.shadowMedium,
                          ),
                          onPressed: () async {
                            if (formKey.currentState!.validate()) {
                              // Handle login logic

                              await loginViewModel.login(
                                emailController.text,
                                passwordController.text,
                              );

                              // print(loginState.user!.email);
                            }
                          },
                          child: const Text(
                            'Login',
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                              color: ColorManager.white,
                            ),
                          ),
                        ),
                ),

                const SizedBox(height: 16),
                TextButton(
                  onPressed: () {
                    context.go('/register');
                  },
                  child: const Text(
                    'dont have an acocunt  ? please Register',
                    style: TextStyle(color: ColorManager.secondary),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
