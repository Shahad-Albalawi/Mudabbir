import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:mudabbir/constants/hive_constants.dart';
import 'package:mudabbir/persentation/budget/budget_viewmodel.dart';
import 'package:mudabbir/persentation/resources/assets_manager.dart';
import 'package:mudabbir/persentation/resources/color_manager.dart';
import 'package:mudabbir/persentation/resources/strings_manager.dart';
import 'package:mudabbir/service/getit_init.dart';
import 'package:mudabbir/service/hive_service.dart';
import 'package:mudabbir/service/navigation_service.dart';

// imports stay the same
class BudgetView extends ConsumerWidget {
  const BudgetView({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final budgetState = ref.watch(budgetViewmodelProvider);
    final budgetViewmodel = ref.read(budgetViewmodelProvider.notifier);
    ref.listen<BudgetState>(budgetViewmodelProvider, (
      previousState,
      newState,
    ) async {
      if (newState.isDelete != null) {
        await budgetViewmodel.getAllBudgets();

        getIt<NavigationService>().showSuccessSnackbar(
          title: 'Success',
          body: 'تم حذف المزانية المقرونة بنجاح',
        );
      }
    });

    return Scaffold(
      appBar: AppBar(
        backgroundColor: ColorManager.primary,
        elevation: 0,
        title: Row(
          children: [
            SvgPicture.asset(
              ImageAssets.onBoardingLogo2,
              fit: BoxFit.contain,
              width: 30,
              height: 30,
            ),
            const SizedBox(width: 10),
            Text(
              '${AppStrings.title} - ${getIt<HiveService>().getValue(HiveConstants.savedUserInfo)['name']}',
              style: Theme.of(context).textTheme.headlineLarge,
            ),
          ],
        ),
        centerTitle: false,
      ),
      body: Builder(
        builder: (context) {
          // Loading
          if (budgetState.isLoading) {
            return const Center(child: CircularProgressIndicator());
          }

          // Empty state (no budgets)
          if (budgetState.budgets.isEmpty) {
            return Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(
                    Icons.account_balance_wallet_outlined,
                    size: 80,
                    color: Colors.grey,
                  ),
                  const SizedBox(height: 20),
                  const Text(
                    "You don’t have any budgets",
                    style: TextStyle(
                      fontSize: 18,
                      color: Colors.grey,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  const SizedBox(height: 20),
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.grey[800],
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(
                        horizontal: 24,
                        vertical: 12,
                      ),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    onPressed: () {
                      // TODO: navigate to Add Budget screen
                    },
                    child: const Text("Add a New Budget"),
                  ),
                ],
              ),
            );
          }

          // Budgets exist → show "Add" button + list
          return Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(16),
                child: ElevatedButton.icon(
                  style: Theme.of(context).elevatedButtonTheme.style,
                  onPressed: () {
                    // TODO: navigate to Add Budget screen
                  },
                  icon: const Icon(Icons.add),
                  label: const Text(
                    "Add a New Budget",
                    style: TextStyle(fontSize: 16),
                  ),
                ),
              ),
              Expanded(
                child: ListView.builder(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  itemCount: budgetState.budgets.length,
                  itemBuilder: (_, i) {
                    final budget = budgetState.budgets[i];
                    return Card(
                      margin: const EdgeInsets.symmetric(vertical: 8),
                      color: Colors.grey[200],
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: ListTile(
                        trailing: IconButton(
                          onPressed: () async {
                            print('deleting..');
                            await budgetViewmodel.deleteBudget(budget['id']);
                          },
                          icon: Icon(
                            Icons.delete_outline_rounded,
                            color: Colors.red,
                          ),
                        ),

                        leading: const Icon(
                          Icons.monetization_on,
                          color: Colors.grey,
                        ),
                        title: Text(
                          "${budget['amount']}", // if budget is a Map
                          style: const TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            color: Colors.black87,
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}
