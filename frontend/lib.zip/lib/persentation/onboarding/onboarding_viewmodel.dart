import 'package:mudabbir/persentation/resources/assets_manager.dart';
import 'package:mudabbir/persentation/resources/strings_manager.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

final onboardingViewModelProvider =
    StateNotifierProvider<OnBoardingViewModel, SliderViewObject>(
      (ref) => OnBoardingViewModel(),
    );

class OnBoardingViewModel extends StateNotifier<SliderViewObject> {
  late final List<SliderObject> _list;
  int _currentIndex = 0;

  OnBoardingViewModel()
    : super(
        SliderViewObject(
          SliderObject(
            AppStrings.onBoardingTitle1,
            AppStrings.onBoardingSubTitle1,
            ImageAssets.onBoardingLogo1,
          ),
          4,
          0,
        ),
      ) {
    _list = _getSliderData();
    _updateState(); // set the initial slide
  }
  List<SliderObject> get slides => _list; // public getter
  // Load all slides
  List<SliderObject> _getSliderData() => [
    SliderObject(
      AppStrings.onBoardingTitle1,
      AppStrings.onBoardingSubTitle1,
      ImageAssets.onBoardingLogo1,
    ),
    SliderObject(
      AppStrings.onBoardingTitle2,
      AppStrings.onBoardingSubTitle2,
      ImageAssets.onBoardingLogo2,
    ),
    SliderObject(
      AppStrings.onBoardingTitle3,
      AppStrings.onBoardingSubTitle3,
      ImageAssets.onBoardingLogo3,
    ),
    SliderObject(
      AppStrings.onBoardingTitle4,
      AppStrings.onBoardingSubTitle4,
      ImageAssets.onBoardingLogo4,
    ),
  ];

  void goNext() {
    _currentIndex = (_currentIndex + 1) % _list.length;
    _updateState();
  }

  void goPrevious() {
    _currentIndex = (_currentIndex - 1 + _list.length) % _list.length;
    _updateState();
  }

  void onPageChanged(int index) {
    _currentIndex = index;
    _updateState();
  }

  void _updateState() {
    state = SliderViewObject(_list[_currentIndex], _list.length, _currentIndex);
  }
}

// SliderViewObject and SliderObject remain the same
class SliderViewObject {
  final SliderObject sliderObject;
  final int numOfSlides;
  final int currentIndex;

  SliderViewObject(this.sliderObject, this.numOfSlides, this.currentIndex);
}

class SliderObject {
  final String title;
  final String subTitle;
  final String image;

  SliderObject(this.title, this.subTitle, this.image);
}
