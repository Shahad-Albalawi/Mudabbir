import 'package:flutter/material.dart';

class ColorManager {
  // Primary Colors
  static const Color primary = Color(0xFF4054B9); // Gold
  static const Color darkPrimary = Color(0xFF11249D); // Darker Gold
  static const Color lightPrimary = Color(0xFF0D1644); // Light Gold

  // Accent / Secondary Colors
  static const Color secondary = Color(0xFF002366); // Dark Blue
  static const Color lightSecondary = Color(0xFF334C99); // Light Blue Accent

  // Greys
  static const Color grey = Color(0xFF737477);
  static const Color grey1 = Color(0xFF707070);
  static const Color grey2 = Color(0xFF797979);
  static const Color lightGrey = Color(0xFFB0B0B0);
  static const Color darkGrey = Color(0xFF525252);

  // Others
  static const Color white = Color(0xFFFFFFFF);
  static const Color black = Color(0xFF000000);
  static const Color error = Color(0xFFE61F34);

  // Background Colors
  static const Color background = Color(0xFFF5F6FA);
  static const Color cardBackground = Color(0xFFFFFFFF);
  static const Color shadow = Color(0x22000000);

  // Enhanced colors for modern onboarding
  static const Color primaryGradientStart = Color(
    0xFFFFB800,
  ); // Your primary gold
  static const Color primaryGradientEnd = Color(
    0xFFFFD366,
  ); // Your light primary
  static const Color onboardingBackground = Color(
    0xFFFAFBFC,
  ); // Very light background
  static const Color onboardingCard = Color(0xFFFFFFFF); // Pure white for cards
  static const Color textPrimary = Color(
    0xFF1A1A1A,
  ); // Almost black for primary text
  static const Color textSecondary = Color(
    0xFF6B7280,
  ); // Grey for secondary text
  static const Color dotInactive = Color(
    0xFFE5E7EB,
  ); // Light grey for inactive dots
  static const Color overlay = Color(0x66000000); // Dark overlay

  // Glassmorphism and modern effects
  static Color get primaryWithOpacity10 => primary.withOpacity(0.1);
  static Color get primaryWithOpacity20 => primary.withOpacity(0.2);
  static Color get primaryWithOpacity30 => primary.withOpacity(0.3);
  static Color get whiteWithOpacity20 => white.withOpacity(0.2);
  static Color get whiteWithOpacity30 => white.withOpacity(0.3);
  static Color get shadowLight => const Color(0x10000000);
  static Color get shadowMedium => const Color(0x20000000);
}
