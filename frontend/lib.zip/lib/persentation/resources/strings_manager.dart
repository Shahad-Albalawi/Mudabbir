class AppStrings {
  static const noRouteFound = 'المسار غير موجود';

  static const onBoardingTitle1 = 'مرحباً بك في مدخر';
  static const onBoardingTitle2 = 'تابع ميزانيتك بسهولة';
  static const onBoardingTitle3 = 'مساعدك الذكي لإدارة المصروفات';
  static const onBoardingTitle4 = 'حقق أهدافك المالية';

  static const onBoardingSubTitle1 =
      'تطبيق مدخر يساعدك على تنظيم نفقاتك ومدخراتك.';
  static const onBoardingSubTitle2 = 'تابع دخلك ومصاريفك اليومية في مكان واحد.';
  static const onBoardingSubTitle3 =
      'استخدم المساعد الذكي للحصول على نصائح مالية مخصصة.';
  static const onBoardingSubTitle4 =
      'ابدأ اليوم بخطتك المالية لتحقيق استقرار أفضل.';

  static const skip = 'تخطي';

  static const title = 'مُدَبِّرٌ';
  static const yourStat = 'تحليلاتك';

  static const totalIncome = 'إجمالي الدخل';
  static const totalExpense = 'إجمالي المصروف';
  static const currentBalance = 'التوفير الحالي';

  static const String addExpense = 'اضافة مصروف';
  static const String addIncome = 'اضافة دخل';
  static const String addChallenge = 'اضافة تحدي';
  static const String StatisticsString =
      'انقر هنا لاستعراض تحليلاتك والأطلاع عل الاحصائيات الخاصة بك';
  static const String budgetString =
      'انقر هنا لادارة ميزانيتك الشهرية واليومية';

  static const String homeText1 = 'أهلا بك في مدبر ';
  static const String homeText2 = 'ابدأ رحلتك نحو ادارة مالبة أفضل معنا';
}
