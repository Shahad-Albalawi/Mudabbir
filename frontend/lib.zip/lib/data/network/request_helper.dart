import 'dart:async';
import 'dart:convert';
import 'package:dartz/dartz.dart';
import 'package:http/http.dart' as http;
import 'failure.dart';

enum HttpMethod { GET, POST }

Future<Either<Failure, T>> requestData<T>({
  required String url,
  required T Function(dynamic json) parser,
  HttpMethod method = HttpMethod.GET,
  Map<String, String>? headers,
  Map<String, dynamic>? body, // used for POST
  Duration timeout = const Duration(seconds: 10),
}) async {
  try {
    http.Response response;

    if (method == HttpMethod.GET) {
      response = await http
          .get(Uri.parse(url), headers: headers)
          .timeout(timeout);
    } else if (method == HttpMethod.POST) {
      response = await http
          .post(
            Uri.parse(url),
            headers: headers ?? {'Content-Type': 'application/json'},
            body: jsonEncode(body ?? {}),
          )
          .timeout(timeout);
    } else {
      return Left(UnknownFailure('Unsupported HTTP method'));
    }

    if (response.statusCode >= 200 && response.statusCode < 300) {
      final data = jsonDecode(response.body);
      return Right(parser(data));
    } else {
      return Left(
        ServerFailure(
          response.statusCode,
          response.reasonPhrase ?? 'Server error',
        ),
      );
    }
  } on TimeoutException catch (e) {
    return Left(TimeoutFailure('Request timed out: ${e.message}'));
  } on http.ClientException catch (e) {
    return Left(NetworkFailure('Network error: ${e.message}'));
  } on FormatException catch (e) {
    return Left(ParsingFailure('Parsing error: ${e.message}'));
  } catch (e) {
    return Left(UnknownFailure('Unexpected error: $e'));
  }
}
