class Failure {
  final int code;
  final String message;
  const Failure(this.code, this.message);
}

class NetworkFailure extends Failure {
  const NetworkFailure(String message) : super(-1, message);
}

class TimeoutFailure extends Failure {
  const TimeoutFailure(String message) : super(-2, message);
}

class ParsingFailure extends Failure {
  const ParsingFailure(String message) : super(-3, message);
}

class ServerFailure extends Failure {
  const ServerFailure(int code, String message) : super(code, message);
}

class UnknownFailure extends Failure {
  const UnknownFailure(String message) : super(-4, message);
}
