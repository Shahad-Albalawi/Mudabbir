import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

class LocalDatabase {
  LocalDatabase._privateConstructor();
  static final LocalDatabase instance = LocalDatabase._privateConstructor();

  static Database? _database;

  Future<Database> get database async {
    if (_database == null) {
      throw Exception("Database not initialized. Call initForUser() first.");
    }
    return _database!;
  }

  /// Initialize DB after registration/login with a unique identifier like an email.
  Future<void> initForUser(String userIdentifier) async {
    final dbName =
        '${userIdentifier.replaceAll(RegExp(r'[^a-zA-Z0-9]'), '_')}_finance.db';
    final path = join(await getDatabasesPath(), dbName);

    _database = await openDatabase(
      path,
      version: 1,
      onCreate: _onCreate,
      onOpen: (db) {
        // Add the PRAGMA command here to ensure it's executed on every open.
        db.execute('PRAGMA foreign_keys = ON');
      },
    );
  }

  /// Creates all the necessary tables for the financial app.
  /// Creates all the necessary tables for the financial app.
  Future _onCreate(Database db, int version) async {
    // Enable foreign key support
    await db.execute('PRAGMA foreign_keys = ON');

    // --- Create tables ---
    await db.execute('''
    CREATE TABLE accounts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      balance REAL NOT NULL DEFAULT 0.0
    )
  ''');

    await db.execute('''
    CREATE TABLE categories (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      type TEXT NOT NULL, -- 'income' or 'expense'
      UNIQUE(name, type)
    )
  ''');

    await db.execute('''
    CREATE TABLE goals (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      target REAL NOT NULL,
      current_amount REAL NOT NULL DEFAULT 0.0,
      type TEXT NOT NULL,
      start_date TEXT NOT NULL,
      end_date TEXT NOT NULL
    )
  ''');

    await db.execute('''
      CREATE TABLE challenges (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      start_date TEXT NOT NULL,
      end_date TEXT NOT NULL,
      status TEXT NOT NULL
    )
  ''');

    await db.execute('''
    CREATE TABLE transactions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      amount REAL NOT NULL,
      date TEXT NOT NULL,
      type TEXT NOT NULL, -- 'income' or 'expense'
      notes TEXT,
      account_id INTEGER NOT NULL,
      category_id INTEGER NOT NULL,
      FOREIGN KEY (account_id) REFERENCES accounts(id) ON DELETE CASCADE,
      FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE RESTRICT
    )
  ''');

    await db.execute('''
    CREATE TABLE budgets (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      amount REAL NOT NULL,
      start_date TEXT NOT NULL,
      end_date TEXT NOT NULL,
      account_id INTEGER NOT NULL,
      FOREIGN KEY (account_id) REFERENCES accounts(id) ON DELETE CASCADE
    )
  ''');

    // --- Insert default data ---

    // Default Accounts
    await db.insert('accounts', {'name': 'النقدية', 'balance': 0.0});
    await db.insert('accounts', {'name': 'البنك', 'balance': 0.0});

    // Income Categories
    final incomeCategories = ['راتب', 'مكافأة', 'هبه', 'اخرى'];
    for (var name in incomeCategories) {
      await db.insert('categories', {'name': name, 'type': 'income'});
    }

    // Expense Categories
    final expenseCategories = [
      'طعام',
      'نقل',
      'تسوق',
      'فواتير',
      'صحة',
      'ترفيه',
      'اخرى',
    ];
    for (var name in expenseCategories) {
      await db.insert('categories', {'name': name, 'type': 'expense'});
    }
  }
}
