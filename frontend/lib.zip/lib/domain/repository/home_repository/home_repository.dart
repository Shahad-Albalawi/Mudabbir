import 'package:mudabbir/data/local/database_helper.dart';
import 'package:mudabbir/service/getit_init.dart';

class HomeRepository {
  final DbHelper _dbHelper = getIt<DbHelper>();

  /// Calculates the sum of all 'income' transactions.
  Future<double> getTotalIncome() async {
    final result = await _dbHelper.complexQuery(
      table: 'transactions',
      columns: ['SUM(amount) as total'],
      where: 'type = ?',
      whereArgs: ['income'],
    );

    // The fold method handles both the 'Left' (failure/empty) and 'Right' (success) cases.
    return result.fold(
      (left) => 0.0, // If no income transactions are found, return 0.0.
      (right) {
        // The result from a SUM query is a list with one map, e.g., [{'total': 5000.0}].
        // If the table is empty, SUM returns NULL, so we handle that case.
        final total = right.first['total'];
        return (total as num?)?.toDouble() ?? 0.0;
      },
    );
  }

  /// Calculates the sum of all 'expense' transactions.
  Future<double> getTotalExpense() async {
    final result = await _dbHelper.complexQuery(
      table: 'transactions',
      columns: ['SUM(amount) as total'],
      where: 'type = ?',
      whereArgs: ['expense'],
    );

    return result.fold(
      (left) => 0.0, // If no expense transactions are found, return 0.0.
      (right) {
        final total = right.first['total'];
        return (total as num?)?.toDouble() ?? 0.0;
      },
    );
  }
}
