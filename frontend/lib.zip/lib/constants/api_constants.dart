class ApiConstants {
  static final String baseUrl = 'http://10.0.2.2:8000';
  static final Map<String, String> headers = {};
  static final Map<String, String> userHeaders = {};
}
