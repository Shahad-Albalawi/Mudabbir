import 'package:dio/dio.dart';
import 'package:mudabbir/persentation/server_challenges/models/challenge_model.dart';
import 'package:mudabbir/persentation/server_challenges/services/api_exception.dart';
import 'package:mudabbir/persentation/server_challenges/utils/dio_client.dart';

class ChallengeService {
  final DioClient _dioClient;

  ChallengeService(this._dioClient);

  // Get all challenges
  Future<List<ChallengeModel>> getChallenges() async {
    try {
      final response = await _dioClient.dio.get('/challenges');

      if (response.data['success'] == true) {
        final List<dynamic> data = response.data['data'] as List<dynamic>;
        return data.map((json) => ChallengeModel.fromJson(json)).toList();
      }

      throw ApiException(message: 'Failed to load challenges');
    } on DioException catch (e) {
      throw ApiException.fromDioError(e);
    }
  }

  // Get single challenge
  Future<ChallengeModel> getChallenge(int id) async {
    try {
      final response = await _dioClient.dio.get('/challenges/$id');

      if (response.data['success'] == true) {
        return ChallengeModel.fromJson(response.data['data']);
      }

      throw ApiException(message: 'Failed to load challenge');
    } on DioException catch (e) {
      throw ApiException.fromDioError(e);
    }
  }

  // Create challenge
  Future<ChallengeModel> createChallenge({
    required String name,
    required double amount,
    required DateTime startDate,
    required DateTime endDate,
  }) async {
    try {
      final response = await _dioClient.dio.post(
        '/challenges',
        data: {
          'name': name,
          'amount': amount,
          'start_date': startDate.toIso8601String().split('T')[0],
          'end_date': endDate.toIso8601String().split('T')[0],
        },
      );

      if (response.data['success'] == true) {
        return ChallengeModel.fromJson(response.data['data']);
      }

      throw ApiException(message: 'Failed to create challenge');
    } on DioException catch (e) {
      throw ApiException.fromDioError(e);
    }
  }

  // Update challenge
  Future<ChallengeModel> updateChallenge({
    required int id,
    String? name,
    double? amount,
    DateTime? startDate,
    DateTime? endDate,
  }) async {
    try {
      final Map<String, dynamic> data = {};

      if (name != null) data['name'] = name;
      if (amount != null) data['amount'] = amount;
      if (startDate != null) {
        data['start_date'] = startDate.toIso8601String().split('T')[0];
      }
      if (endDate != null) {
        data['end_date'] = endDate.toIso8601String().split('T')[0];
      }

      final response = await _dioClient.dio.put('/challenges/$id', data: data);

      if (response.data['success'] == true) {
        return ChallengeModel.fromJson(response.data['data']);
      }

      throw ApiException(message: 'Failed to update challenge');
    } on DioException catch (e) {
      throw ApiException.fromDioError(e);
    }
  }

  // Delete challenge
  Future<void> deleteChallenge(int id) async {
    try {
      final response = await _dioClient.dio.delete('/challenges/$id');

      if (response.data['success'] != true) {
        throw ApiException(message: 'Failed to delete challenge');
      }
    } on DioException catch (e) {
      throw ApiException.fromDioError(e);
    }
  }

  // Invite user to challenge
  Future<ChallengeModel> inviteUser({
    required int challengeId,
    required String email,
  }) async {
    try {
      final response = await _dioClient.dio.post(
        '/challenges/$challengeId/invite',
        data: {'email': email},
      );

      if (response.data['success'] == true) {
        return ChallengeModel.fromJson(response.data['data']);
      }

      throw ApiException(message: 'Failed to invite user');
    } on DioException catch (e) {
      throw ApiException.fromDioError(e);
    }
  }

  // Remove participant
  Future<ChallengeModel> removeParticipant({
    required int challengeId,
    required int userId,
  }) async {
    try {
      final response = await _dioClient.dio.delete(
        '/challenges/$challengeId/participants/$userId',
      );

      if (response.data['success'] == true) {
        return ChallengeModel.fromJson(response.data['data']);
      }

      throw ApiException(message: 'Failed to remove participant');
    } on DioException catch (e) {
      throw ApiException.fromDioError(e);
    }
  }

  // Toggle challenge status
  Future<ChallengeModel> toggleStatus(int challengeId) async {
    try {
      final response = await _dioClient.dio.patch(
        '/challenges/$challengeId/status',
      );

      if (response.data['success'] == true) {
        return ChallengeModel.fromJson(response.data['data']);
      }

      throw ApiException(message: 'Failed to update status');
    } on DioException catch (e) {
      throw ApiException.fromDioError(e);
    }
  }

  // NEW: Accept or reject invitation
  Future<ChallengeModel> respondToInvitation({
    required int challengeId,
    required String status, // 'accepted' or 'rejected'
  }) async {
    try {
      final response = await _dioClient.dio.post(
        '/challenges/$challengeId/respond',
        data: {'status': status},
      );

      if (response.data['success'] == true) {
        return ChallengeModel.fromJson(response.data['data']);
      }

      throw ApiException(message: 'Failed to respond to invitation');
    } on DioException catch (e) {
      throw ApiException.fromDioError(e);
    }
  }

  // NEW: Get pending invitations
  Future<List<ChallengeModel>> getPendingInvitations() async {
    try {
      final response = await _dioClient.dio.get(
        '/challenges/invitations/pending',
      );

      if (response.data['success'] == true) {
        final List<dynamic> data = response.data['data'] as List<dynamic>;
        return data.map((json) => ChallengeModel.fromJson(json)).toList();
      }

      throw ApiException(message: 'Failed to load pending invitations');
    } on DioException catch (e) {
      throw ApiException.fromDioError(e);
    }
  }
}
