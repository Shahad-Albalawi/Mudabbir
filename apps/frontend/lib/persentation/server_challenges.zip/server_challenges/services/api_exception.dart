import 'package:dio/dio.dart';

class ApiException implements Exception {
  final String message;
  final int? statusCode;
  final dynamic errors;

  ApiException({required this.message, this.statusCode, this.errors});

  factory ApiException.fromDioError(DioException error) {
    switch (error.type) {
      case DioExceptionType.connectionTimeout:
      case DioExceptionType.sendTimeout:
      case DioExceptionType.receiveTimeout:
        return ApiException(
          message: 'Connection timeout. Please check your internet connection.',
          statusCode: null,
        );

      case DioExceptionType.badResponse:
        return _handleBadResponse(error.response);

      case DioExceptionType.cancel:
        return ApiException(message: 'Request was cancelled', statusCode: null);

      case DioExceptionType.connectionError:
        return ApiException(
          message: 'No internet connection. Please check your network.',
          statusCode: null,
        );

      case DioExceptionType.badCertificate:
        return ApiException(
          message: 'Security certificate error',
          statusCode: null,
        );

      case DioExceptionType.unknown:
      default:
        return ApiException(
          message: 'Something went wrong. Please try again.',
          statusCode: null,
        );
    }
  }

  static ApiException _handleBadResponse(Response? response) {
    if (response == null) {
      return ApiException(message: 'Unknown error occurred', statusCode: null);
    }

    final statusCode = response.statusCode ?? 0;
    final data = response.data;

    // Handle Laravel API response format
    if (data is Map<String, dynamic>) {
      final message = data['message'] as String?;
      final errors = data['errors'];

      if (errors != null) {
        // Validation errors
        return ApiException(
          message: message ?? 'Validation failed',
          statusCode: statusCode,
          errors: errors,
        );
      }

      if (message != null) {
        return ApiException(message: message, statusCode: statusCode);
      }
    }

    // Default error messages based on status code
    switch (statusCode) {
      case 400:
        return ApiException(message: 'Bad request', statusCode: statusCode);
      case 401:
        return ApiException(
          message: 'Unauthorized. Please login again.',
          statusCode: statusCode,
        );
      case 403:
        return ApiException(message: 'Access denied', statusCode: statusCode);
      case 404:
        return ApiException(
          message: 'Resource not found',
          statusCode: statusCode,
        );
      case 422:
        return ApiException(
          message: 'Validation error',
          statusCode: statusCode,
        );
      case 500:
        return ApiException(
          message: 'Server error. Please try again later.',
          statusCode: statusCode,
        );
      default:
        return ApiException(
          message: 'Error occurred (Code: $statusCode)',
          statusCode: statusCode,
        );
    }
  }

  // Get formatted error message for validation errors
  String getValidationMessage() {
    if (errors == null) return message;

    if (errors is Map<String, dynamic>) {
      final firstError = errors.values.first;
      if (firstError is List && firstError.isNotEmpty) {
        return firstError.first.toString();
      }
    }

    return message;
  }

  @override
  String toString() => message;
}
