import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:mudabbir/persentation/resources/color_manager.dart';
import 'package:mudabbir/persentation/resources/font_manager.dart';
import 'package:mudabbir/persentation/resources/styles_manager.dart';
import 'package:mudabbir/persentation/server_challenges/providers/challenge_provider.dart';
import 'package:mudabbir/persentation/server_challenges/providers/challenge_state.dart';
import 'package:mudabbir/persentation/server_challenges/screens/create_challenge_screen.dart';
import 'package:mudabbir/persentation/server_challenges/widgets/challenge_card.dart';
import 'package:mudabbir/service/getit_init.dart';
import 'package:mudabbir/service/navigation_service.dart';

class ChallengesListScreen extends ConsumerStatefulWidget {
  const ChallengesListScreen({super.key});

  @override
  ConsumerState<ChallengesListScreen> createState() =>
      _ChallengesListScreenState();
}

class _ChallengesListScreenState extends ConsumerState<ChallengesListScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);

    Future.microtask(
      () => ref.read(challengesProvider.notifier).loadChallenges(),
    );
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final challengeState = ref.watch(challengesProvider);

    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              ColorManager.primary,
              ColorManager.primary.withOpacity(0.8),
            ],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              _buildAppBar(context),
              _buildTabBar(),
              Expanded(
                child: Container(
                  decoration: const BoxDecoration(
                    color: Color(0xFFF8F9FA),
                    borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(32),
                      topRight: Radius.circular(32),
                    ),
                  ),
                  child: _buildBody(challengeState),
                ),
              ),
            ],
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _navigateToCreateChallenge(context),
        icon: const Icon(Icons.add),
        label: const Text('تحدٍ جديد'),
      ),
    );
  }

  Widget _buildAppBar(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(20),
      child: Row(
        children: [
          IconButton(
            onPressed: () => Navigator.pop(context),
            icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
          ),
          const SizedBox(width: 8),
          Text(
            'التحديات',
            style: getBoldStyle(fontSize: FontSize.s24, color: Colors.white),
          ),
          const Spacer(),
          IconButton(
            onPressed: () =>
                ref.read(challengesProvider.notifier).refreshChallenges(),
            icon: const Icon(Icons.refresh, color: Colors.white),
          ),
        ],
      ),
    );
  }

  Widget _buildTabBar() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.2),
        borderRadius: BorderRadius.circular(16),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(16),
        child: TabBar(
          controller: _tabController,
          indicatorSize: TabBarIndicatorSize.tab,
          labelPadding: EdgeInsets.zero,
          indicator: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
          ),
          labelColor: ColorManager.primary,
          unselectedLabelColor: Colors.white.withOpacity(0.7),
          labelStyle: getMediumStyle(
            fontSize: FontSize.s12,
            color: Colors.black,
          ),
          dividerColor: Colors.transparent,
          tabs: const [
            Tab(text: 'الحالية'),
            Tab(text: 'القادمة'),
            Tab(text: 'المكتملة'),
            Tab(text: 'المنتهية'),
          ],
        ),
      ),
    );
  }

  Widget _buildBody(ChallengeState state) {
    return switch (state) {
      ChallengeInitial() => const SizedBox.shrink(),
      ChallengeLoading() => const Center(child: CircularProgressIndicator()),
      ChallengeError(:final message) => _buildError(message),
      ChallengeLoaded() => _buildTabBarView(state),
    };
  }

  Widget _buildTabBarView(ChallengeLoaded state) {
    return TabBarView(
      controller: _tabController,
      children: [
        _buildChallengesList(state.activeChallenges, 'لا توجد تحديات حالية'),
        _buildChallengesList(state.upcomingChallenges, 'لا توجد تحديات قادمة'),
        _buildChallengesList(
          state.completedChallenges,
          'لا توجد تحديات مكتملة',
        ),
        _buildChallengesList(state.expiredChallenges, 'لا توجد تحديات منتهية'),
      ],
    );
  }

  Widget _buildChallengesList(List challenges, String emptyMessage) {
    if (challenges.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.inbox_outlined,
              size: 80,
              color: ColorManager.grey.withOpacity(0.3),
            ),
            const SizedBox(height: 16),
            Text(
              emptyMessage,
              style: getMediumStyle(
                fontSize: FontSize.s16,
                color: ColorManager.grey1,
              ),
            ),
          ],
        ),
      );
    }

    return RefreshIndicator(
      onRefresh: () =>
          ref.read(challengesProvider.notifier).refreshChallenges(),
      child: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: challenges.length,
        itemBuilder: (context, index) {
          return ChallengeCard(challenge: challenges[index]);
        },
      ),
    );
  }

  Widget _buildError(String message) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.error_outline,
              size: 80,
              color: ColorManager.error.withOpacity(0.5),
            ),
            const SizedBox(height: 16),
            Text(
              message,
              textAlign: TextAlign.center,
              style: getMediumStyle(
                fontSize: FontSize.s16,
                color: ColorManager.darkGrey,
              ),
            ),
            const SizedBox(height: 24),
            ElevatedButton.icon(
              onPressed: () =>
                  ref.read(challengesProvider.notifier).loadChallenges(),
              icon: const Icon(Icons.refresh),
              label: const Text('إعادة المحاولة'),
            ),
          ],
        ),
      ),
    );
  }

  void _navigateToCreateChallenge(BuildContext context) {
    getIt<NavigationService>().navigate(const CreateChallengeScreen());
  }
}
