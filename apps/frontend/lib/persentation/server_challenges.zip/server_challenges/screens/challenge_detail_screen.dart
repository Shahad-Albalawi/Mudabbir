import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:mudabbir/persentation/resources/color_manager.dart';
import 'package:mudabbir/persentation/resources/font_manager.dart';
import 'package:mudabbir/persentation/resources/styles_manager.dart';
import 'package:mudabbir/persentation/server_challenges/models/challenge_model.dart';
import 'package:mudabbir/persentation/server_challenges/providers/challenge_provider.dart';
import 'package:mudabbir/persentation/server_challenges/providers/challenge_state.dart';
import 'package:mudabbir/persentation/server_challenges/widgets/participant_item.dart';
import 'package:intl/intl.dart';

class ChallengeDetailScreen extends ConsumerStatefulWidget {
  final int challengeId;

  const ChallengeDetailScreen({super.key, required this.challengeId});

  @override
  ConsumerState<ChallengeDetailScreen> createState() =>
      _ChallengeDetailScreenState();
}

class _ChallengeDetailScreenState extends ConsumerState<ChallengeDetailScreen> {
  @override
  void initState() {
    super.initState();
    Future.microtask(() {
      ref
          .read(challengeDetailProvider(widget.challengeId).notifier)
          .loadChallenge();
    });
  }

  @override
  Widget build(BuildContext context) {
    final detailState = ref.watch(challengeDetailProvider(widget.challengeId));

    // Listen to operation state for updates
    ref.listen<ChallengeOperationState>(challengeOperationProvider, (
      previous,
      next,
    ) {
      if (next is ChallengeOperationSuccess) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(next.message),
            backgroundColor: const Color(0xFF4CAF50),
          ),
        );

        // Update local challenge if available
        if (next.challenge != null) {
          ref
              .read(challengeDetailProvider(widget.challengeId).notifier)
              .updateLocalChallenge(next.challenge!);
        }
      } else if (next is ChallengeOperationError) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(next.message),
            backgroundColor: ColorManager.error,
          ),
        );
      }
    });

    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              ColorManager.primary,
              ColorManager.primary.withOpacity(0.8),
            ],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              _buildAppBar(context, detailState),
              Expanded(
                child: Container(
                  decoration: const BoxDecoration(
                    color: Color(0xFFF8F9FA),
                    borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(32),
                      topRight: Radius.circular(32),
                    ),
                  ),
                  child: _buildBody(detailState),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildAppBar(BuildContext context, ChallengeDetailState state) {
    return Padding(
      padding: const EdgeInsets.all(20),
      child: Row(
        children: [
          IconButton(
            onPressed: () => Navigator.pop(context),
            icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              'Challenge Details',
              style: getBoldStyle(fontSize: FontSize.s24, color: Colors.white),
            ),
          ),
          if (state is ChallengeDetailLoaded)
            PopupMenuButton<String>(
              icon: const Icon(Icons.more_vert, color: Colors.white),
              onSelected: (value) => _handleMenuAction(value, state.challenge),
              itemBuilder: (context) => [
                const PopupMenuItem(
                  value: 'edit',
                  child: Row(
                    children: [
                      Icon(Icons.edit),
                      SizedBox(width: 8),
                      Text('Edit Challenge'),
                    ],
                  ),
                ),
                const PopupMenuItem(
                  value: 'delete',
                  child: Row(
                    children: [
                      Icon(Icons.delete, color: Colors.red),
                      SizedBox(width: 8),
                      Text(
                        'Delete Challenge',
                        style: TextStyle(color: Colors.red),
                      ),
                    ],
                  ),
                ),
              ],
            ),
        ],
      ),
    );
  }

  Widget _buildBody(ChallengeDetailState state) {
    return switch (state) {
      ChallengeDetailInitial() => const SizedBox.shrink(),
      ChallengeDetailLoading() => const Center(
        child: CircularProgressIndicator(),
      ),
      ChallengeDetailError(:final message) => _buildError(message),
      ChallengeDetailLoaded(:final challenge) => _buildContent(challenge),
    };
  }

  Widget _buildError(String message) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.error_outline,
              size: 80,
              color: ColorManager.error.withOpacity(0.5),
            ),
            const SizedBox(height: 16),
            Text(
              message,
              textAlign: TextAlign.center,
              style: getMediumStyle(
                fontSize: FontSize.s16,
                color: ColorManager.darkGrey,
              ),
            ),
            const SizedBox(height: 24),
            ElevatedButton.icon(
              onPressed: () => ref
                  .read(challengeDetailProvider(widget.challengeId).notifier)
                  .loadChallenge(),
              icon: const Icon(Icons.refresh),
              label: const Text('Retry'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildContent(ChallengeModel challenge) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildInfoCard(challenge),
          const SizedBox(height: 16),
          _buildStatusCard(challenge),
          const SizedBox(height: 16),
          _buildParticipantsCard(challenge),
        ],
      ),
    );
  }

  Widget _buildInfoCard(ChallengeModel challenge) {
    final dateFormat = DateFormat('MMMM d, yyyy');

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              challenge.name,
              style: getBoldStyle(
                fontSize: FontSize.s20,
                color: ColorManager.darkGrey,
              ),
            ),
            const SizedBox(height: 16),
            _buildInfoRow(
              Icons.calendar_today,
              'Start Date',
              dateFormat.format(challenge.startDate),
            ),
            const SizedBox(height: 12),
            _buildInfoRow(
              Icons.event,
              'End Date',
              dateFormat.format(challenge.endDate),
            ),
            if (challenge.isActive || challenge.isUpcoming) ...[
              const SizedBox(height: 16),
              _buildProgressSection(challenge),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildInfoRow(IconData icon, String label, String value) {
    return Row(
      children: [
        Icon(icon, size: 20, color: ColorManager.grey1),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                label,
                style: getRegularStyle(
                  fontSize: FontSize.s12,
                  color: ColorManager.grey1,
                ),
              ),
              const SizedBox(height: 2),
              Text(
                value,
                style: getMediumStyle(
                  fontSize: FontSize.s14,
                  color: ColorManager.darkGrey,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildProgressSection(ChallengeModel challenge) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              challenge.isUpcoming
                  ? 'Starts in ${challenge.daysRemaining} days'
                  : '${challenge.daysRemaining} days remaining',
              style: getMediumStyle(
                fontSize: FontSize.s14,
                color: ColorManager.grey1,
              ),
            ),
            Text(
              '${(challenge.progress * 100).toInt()}%',
              style: getBoldStyle(
                fontSize: FontSize.s16,
                color: ColorManager.primary,
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        ClipRRect(
          borderRadius: BorderRadius.circular(8),
          child: LinearProgressIndicator(
            value: challenge.progress,
            minHeight: 12,
            backgroundColor: ColorManager.grey.withOpacity(0.2),
            valueColor: AlwaysStoppedAnimation<Color>(
              challenge.isUpcoming
                  ? const Color(0xFFFF9800)
                  : ColorManager.primary,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildStatusCard(ChallengeModel challenge) {
    final (color, icon, text) = _getStatusInfo(challenge);

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: color.withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(icon, color: color, size: 32),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Status',
                    style: getRegularStyle(
                      fontSize: FontSize.s12,
                      color: ColorManager.grey1,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    text,
                    style: getBoldStyle(fontSize: FontSize.s18, color: color),
                  ),
                ],
              ),
            ),
            if (!challenge.isExpired)
              ElevatedButton(
                onPressed: () => _toggleStatus(challenge),
                style: ElevatedButton.styleFrom(
                  backgroundColor: color,
                  padding: const EdgeInsets.symmetric(
                    horizontal: 20,
                    vertical: 12,
                  ),
                ),
                child: Text(
                  challenge.achieved ? 'Mark Incomplete' : 'Mark Achieved',
                  style: const TextStyle(fontSize: 12),
                ),
              ),
          ],
        ),
      ),
    );
  }

  (Color, IconData, String) _getStatusInfo(ChallengeModel challenge) {
    if (challenge.achieved) {
      return (const Color(0xFF4CAF50), Icons.check_circle, 'Achieved');
    } else if (challenge.isExpired) {
      return (ColorManager.error, Icons.cancel, 'Expired');
    } else if (challenge.isActive) {
      return (ColorManager.primary, Icons.trending_up, 'Active');
    } else {
      return (const Color(0xFFFF9800), Icons.schedule, 'Upcoming');
    }
  }

  Widget _buildParticipantsCard(ChallengeModel challenge) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Participants (${challenge.participants.length})',
                  style: getBoldStyle(
                    fontSize: FontSize.s16,
                    color: ColorManager.darkGrey,
                  ),
                ),
                TextButton.icon(
                  onPressed: () => _showInviteDialog(challenge),
                  icon: const Icon(Icons.person_add, size: 18),
                  label: const Text('Invite'),
                ),
              ],
            ),
            const SizedBox(height: 16),
            ...challenge.participants.map((participant) {
              return ParticipantItem(
                participant: participant,
                isCreator: participant.id == challenge.creatorId,
                onRemove: participant.id != challenge.creatorId
                    ? () => _removeParticipant(challenge, participant.id)
                    : null,
              );
            }),
          ],
        ),
      ),
    );
  }

  void _toggleStatus(ChallengeModel challenge) {
    ref.read(challengeOperationProvider.notifier).toggleStatus(challenge.id);
  }

  void _showInviteDialog(ChallengeModel challenge) {
    final emailController = TextEditingController();

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Invite User'),
        content: TextField(
          controller: emailController,
          decoration: const InputDecoration(
            labelText: 'Email Address',
            hintText: 'Enter user email',
            prefixIcon: Icon(Icons.email),
          ),
          keyboardType: TextInputType.emailAddress,
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              final email = emailController.text.trim();
              if (email.isNotEmpty) {
                Navigator.pop(context);
                ref
                    .read(challengeOperationProvider.notifier)
                    .inviteUser(challengeId: challenge.id, email: email);
              }
            },
            child: const Text('Invite'),
          ),
        ],
      ),
    );
  }

  void _removeParticipant(ChallengeModel challenge, int userId) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Remove Participant'),
        content: const Text(
          'Are you sure you want to remove this participant?',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              ref
                  .read(challengeOperationProvider.notifier)
                  .removeParticipant(challengeId: challenge.id, userId: userId);
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: ColorManager.error,
            ),
            child: const Text('Remove'),
          ),
        ],
      ),
    );
  }

  void _handleMenuAction(String action, ChallengeModel challenge) {
    if (action == 'delete') {
      _showDeleteDialog(challenge);
    }
    // Add edit functionality if needed
  }

  void _showDeleteDialog(ChallengeModel challenge) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete Challenge'),
        content: const Text(
          'Are you sure you want to delete this challenge? This action cannot be undone.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context); // Close dialog
              ref
                  .read(challengeOperationProvider.notifier)
                  .deleteChallenge(challenge.id);
              Navigator.pop(context); // Go back to list
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: ColorManager.error,
            ),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
  }
}
